import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PopupModule } from './popup/popup.module';
import { NiceModule } from './nice/nice.module';
import { Comp1Component } from './nice/comp1/comp1.component';
import { Comp2Component } from './nice/comp2/comp2.component';
import { Pop1Component } from './popup/pop1/pop1.component';
import { Pop2Component } from './popup/pop2/pop2.component';

const routes: Routes = [
  {
    path: 'comp1',
    component: Comp1Component
  },
  {
    path: 'comp2',
    component: Comp2Component
  },
  {
    path: 'pop1',
    component: Pop1Component,
    outlet: 'popup'
  },
  {
    path: 'pop2',
    component: Pop2Component,
    outlet: 'popup'
  },
  {
    path: 'pop2/:id',
    component: Pop2Component,
    outlet: 'popup'
  },
  {
    path: '',
    redirectTo: 'comp1',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: 'comp1',
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes), PopupModule, NiceModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
