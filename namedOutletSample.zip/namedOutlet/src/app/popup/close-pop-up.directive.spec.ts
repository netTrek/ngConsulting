import { ClosePopUpDirective } from './close-pop-up.directive';

describe('ClosePopUpDirective', () => {
  it('should create an instance', () => {
    const directive = new ClosePopUpDirective();
    expect(directive).toBeTruthy();
  });
});
