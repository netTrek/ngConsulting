import { Directive, HostListener } from '@angular/core';
import { Router } from '@angular/router';

@Directive({
  selector: '[ntClosePopUp]'
})
export class ClosePopUpDirective {

  constructor( private router: Router ) { }

  @HostListener('click')
  close() {
    this.router.navigate([{ outlets: { popup: null } }])/*
        .then(() => this.router.navigate(['../']))*/;
  }

}
